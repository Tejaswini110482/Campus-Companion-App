import Assignment from "../models/Assignment.js";

// Create assignment
export const createAssignment = async (req, res) => {
  try {
    const { title, description, dueDate } = req.body;
    const assignment = await Assignment.create({
      title,
      description,
      dueDate,
      createdBy: req.user._id,
    });
    res.status(201).json(assignment);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get all assignments
export const getAssignments = async (req, res) => {
  try {
    const assignments = await Assignment.find().populate("createdBy", "name email");
    res.status(200).json(assignments);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
