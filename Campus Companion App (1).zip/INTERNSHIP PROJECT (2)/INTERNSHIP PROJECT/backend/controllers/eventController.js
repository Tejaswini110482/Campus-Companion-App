import Event from "../models/Event.js";

// Create event
export const createEvent = async (req, res) => {
  try {
    const { title, description, eventDate } = req.body;
    const event = await Event.create({
      title,
      description,
      eventDate,
      createdBy: req.user._id,
    });
    res.status(201).json(event);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get events
export const getEvents = async (req, res) => {
  try {
    const events = await Event.find().populate("createdBy", "name email");
    res.status(200).json(events);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
