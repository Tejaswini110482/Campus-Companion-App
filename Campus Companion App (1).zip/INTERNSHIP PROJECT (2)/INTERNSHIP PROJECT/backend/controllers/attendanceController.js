import Attendance from "../models/Attendance.js";

// Mark attendance
export const markAttendance = async (req, res) => {
  try {
    const { studentId, status } = req.body;
    const attendance = await Attendance.create({
      student: studentId,
      status,
    });
    res.status(201).json(attendance);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get attendance
export const getAttendance = async (req, res) => {
  try {
    let attendance;
    if (req.user.role === "teacher") {
      attendance = await Attendance.find().populate("student", "name email");
    } else {
      attendance = await Attendance.find({ student: req.user._id });
    }
    res.status(200).json(attendance);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
